package com.cg;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Employee {
	
	@NotNull(message="eno cannot be null")
	Integer eno;
	@Pattern(regexp="[a-z] {5,10}",message="sorry invalid employee")
	String ename;
	int sal;
	public Employee() {
		super();
	}
	public Employee(Integer eno, String ename, int sal) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.sal = sal;
	}
	public Integer getEno() {
		return eno;
	}
	public void setEno(Integer eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", sal=" + sal + "]";
	}
	

}
