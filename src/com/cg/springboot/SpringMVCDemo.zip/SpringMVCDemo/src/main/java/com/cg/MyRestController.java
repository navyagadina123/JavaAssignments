package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest")
public class MyRestController {
	
	@Autowired
	EmpDao dao;
	
	@GetMapping("/hello")
public String getData()	{
		return "Hello world";
	}
	
	@GetMapping("/emp")
	public Employee getEmp() {
		Employee e=new Employee(2,"Nayana",3000);
		return e;
	}
    @GetMapping("/allemp")
    public List<Employee> getAllEmployes(){
    	List<Employee> al=dao.getAllEmployee();
    	return al;
    }
    @PostMapping("/addemp")
    public Employee modifyEmployee(@RequestBody Employee e) {
    	Employee e1=dao.modEmp(e);
    	return e1;
    }
    @PutMapping("/modemp")
    public Employee modifyEmployee1(@RequestBody Employee e) {
    	Employee e1=dao.modEmp(e);
    	return e1;
    }
    @DeleteMapping("/delemp")
    public Employee deleteEmployee(@RequestBody Employee e) {
    	Employee e1=dao.delEmp(e);
    	return e1;
    }
    @GetMapping("/search/{id}")
    public Employee getEmployee(@PathVariable("id")int id) {
    	Employee e=dao.searchEmp(id);
    	return e;
    }
    }
    

