package com.cg;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@RequestMapping("/empLogin")
	public String sayEmpLogin() {
		return "Emp";
	}

	@RequestMapping("/empReg")
		public String getEmpRegDetails(@ModelAttribute("empdata") @Valid Employee e,BindingResult br) {
		if(br.hasErrors())
			return "Emp";
		return "empReg";
	}
	
	@ModelAttribute("empdata")
	public Employee getDetails() {
		return new Employee(1,"Navya",900);
	}
	
}


