package com.cg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EmpDao {
	HashMap<Integer,Employee> hm=new HashMap<Integer,Employee>();
	public EmpDao() {
		hm.put(1, new Employee(1,"Navya",3000));
		hm.put(2, new Employee(2,"Bhavya",5000));
		hm.put(3, new Employee(3,"keerthi",4000));
		hm.put(4, new Employee(4,"Ramya",6000));
		
		
	}
	public List<Employee> getAllEmployee(){
		return new ArrayList<Employee>(hm.values());
	}
   
	public Employee searchEmp(int id) {
		return hm.get(id);
	}
	public Employee  modEmp(Employee e) {
		hm.put(e.getEno(),e);
		return e;
	}
	public Employee delEmp(Employee e) {
		return hm.remove(e.getEno());
	}
	
	}

