package com.cg.opna.exception;

public class PlantAlreadyPresentException extends Exception {
	public PlantAlreadyPresentException(String msg) {
		super(msg);
	}

}
