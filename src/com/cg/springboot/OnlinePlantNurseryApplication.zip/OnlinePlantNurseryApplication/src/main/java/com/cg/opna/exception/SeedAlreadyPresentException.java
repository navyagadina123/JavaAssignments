package com.cg.opna.exception;

public class SeedAlreadyPresentException extends Exception {
	public SeedAlreadyPresentException(String str) {
		super(str);
	}

}
