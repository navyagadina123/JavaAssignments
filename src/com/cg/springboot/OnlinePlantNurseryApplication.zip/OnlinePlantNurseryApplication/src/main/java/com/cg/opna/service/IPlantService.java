package com.cg.opna.service;

import java.util.List;

import com.cg.opna.exception.PlantAlreadyPresentException;
import com.cg.opna.exception.PlantNotFoundException;
import com.cg.opna.model.Plant;


	public interface IPlantService {
		public Plant addPlant(Plant plant) throws PlantAlreadyPresentException;
		public Plant updatePlant(Plant plant) throws PlantNotFoundException;
		public   List<Plant> viewAllPlants() throws PlantNotFoundException;
		public Plant deletePlant(Plant plant) throws PlantNotFoundException; 
		public Plant viewPlant(int plantId) throws PlantNotFoundException;
		public Plant viewPlant(String commonName)throws PlantNotFoundException;
		public List<Plant> viewAllPlants(String typeOfPlant)throws PlantNotFoundException;

	}



