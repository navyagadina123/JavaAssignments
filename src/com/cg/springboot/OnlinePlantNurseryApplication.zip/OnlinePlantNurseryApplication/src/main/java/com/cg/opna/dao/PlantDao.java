package com.cg.opna.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.opna.model.Plant;

@Repository
public interface PlantDao extends JpaRepository<Plant,Integer> {
	
	@Query("select pname from Plant pname where pname.commonName=?1")
	public Plant viewPlant(String commonName);
	
	@Query("select plttype from Plant plttype where plttype.typeOfPlant=?1")
	public List<Plant> viewAllPlants(String typeOfPlant);

}

