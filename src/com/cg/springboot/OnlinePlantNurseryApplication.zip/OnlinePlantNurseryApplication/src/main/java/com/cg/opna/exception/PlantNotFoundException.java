package com.cg.opna.exception;

public class PlantNotFoundException extends Exception {
  public PlantNotFoundException(String msg) {
	  super(msg);
  }
}
