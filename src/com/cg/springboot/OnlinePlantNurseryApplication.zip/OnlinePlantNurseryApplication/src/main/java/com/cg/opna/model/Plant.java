package com.cg.opna.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="Plant")
	public class Plant {
		
		@Id
		Integer plantId;
		@Column(name="plantheight")
		Integer plantHeight;
		@Column(name="plantspread",length=50)
		String plantSpread;
		@Column(name="commonName",length=60)
		String commonName;
		@Column(name="bloomTime",length=70)
		String bloomTime;
		@Column(name="medcinalOrCullinaryUse",length=80)
		String medicinalOrCullinaryUse;
		@Column(name="difficultyLevel",length=60)
		String difficultyLevel;
		@Column(name="temperature",length=60)
		String temperature;
		@Column(name="planttype",length=40)
		String typeOfPlant;
		@Column(name="planttdescription",length=60)
		String plantDescription;
		@Column(name="plantstock")
		Integer plantsStock;
		@Column(name="cost")
		double cost;
		
		
		public Plant() {
			super();
		}


		public Plant(Integer plantId, Integer plantHeight, String plantSpread, String commonName, String bloomTime,
				String medicinalOrCullinaryUse, String difficultyLevel, String temperature, String typeOfPlant,
				String plantDescription, Integer plantsStock, double cost) {
			super();
			this.plantId = plantId;
			this.plantHeight = plantHeight;
			this.plantSpread = plantSpread;
			this.commonName = commonName;
			this.bloomTime = bloomTime;
			this.medicinalOrCullinaryUse = medicinalOrCullinaryUse;
			this.difficultyLevel = difficultyLevel;
			this.temperature = temperature;
			this.typeOfPlant = typeOfPlant;
			this.plantDescription = plantDescription;
			this.plantsStock = plantsStock;
			this.cost = cost;
		}


		public Integer getPlantId() {
			return plantId;
		}


		public void setPlantId(Integer plantId) {
			this.plantId = plantId;
		}


		public Integer getPlantHeight() {
			return plantHeight;
		}


		public void setPlantHeight(Integer plantHeight) {
			this.plantHeight = plantHeight;
		}


		public String getPlantSpread() {
			return plantSpread;
		}


		public void setPlantSpread(String plantSpread) {
			this.plantSpread = plantSpread;
		}


		public String getCommonName() {
			return commonName;
		}


		public void setCommonName(String commonName) {
			this.commonName = commonName;
		}


		public String getBloomTime() {
			return bloomTime;
		}


		public void setBloomTime(String bloomTime) {
			this.bloomTime = bloomTime;
		}


		public String getMedicinalOrCullinaryUse() {
			return medicinalOrCullinaryUse;
		}


		public void setMedicinalOrCullinaryUse(String medicinalOrCullinaryUse) {
			this.medicinalOrCullinaryUse = medicinalOrCullinaryUse;
		}


		public String getDifficultyLevel() {
			return difficultyLevel;
		}


		public void setDifficultyLevel(String difficultyLevel) {
			this.difficultyLevel = difficultyLevel;
		}


		public String getTemperature() {
			return temperature;
		}


		public void setTemperature(String temperature) {
			this.temperature = temperature;
		}


		public String getTypeOfPlant() {
			return typeOfPlant;
		}


		public void setTypeOfPlant(String typeOfPlant) {
			this.typeOfPlant = typeOfPlant;
		}


		public String getPlantDescription() {
			return plantDescription;
		}


		public void setPlantDescription(String plantDescription) {
			this.plantDescription = plantDescription;
		}


		public Integer getPlantsStock() {
			return plantsStock;
		}


		public void setPlantsStock(Integer plantsStock) {
			this.plantsStock = plantsStock;
		}


		public double getCost() {
			return cost;
		}


		public void setCost(double cost) {
			this.cost = cost;
		}


		@Override
		public String toString() {
			return "Plant [plantId=" + plantId + ", plantHeight=" + plantHeight + ", plantSpread=" + plantSpread
					+ ", commonName=" + commonName + ", bloomTime=" + bloomTime + ", medicinalOrCullinaryUse="
					+ medicinalOrCullinaryUse + ", difficultyLevel=" + difficultyLevel + ", temperature=" + temperature
					+ ", typeOfPlant=" + typeOfPlant + ", plantDescription=" + plantDescription + ", plantsStock="
					+ plantsStock + ", cost=" + cost + "]";
		}
		
		
	}
		


		
