package com.cg.opna.exception;

public class CustomerNotFoundException extends Exception {
public CustomerNotFoundException(String str) {
	super(str);
}
}
