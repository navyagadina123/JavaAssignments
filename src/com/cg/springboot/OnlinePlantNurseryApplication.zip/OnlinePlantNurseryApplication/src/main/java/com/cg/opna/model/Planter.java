package com.cg.opna.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="Planter")
public class Planter {
	@Id
	Integer planterId;
	@Column(name="plantheight")
	float planterHeight;
	@Column(name="plantcapacity",length=50)
	int planterCapacity;
	@Column(name="drinageholes",length=50)
	int drinageHoles;
	@Column(name="planttcolor",length=50)
	int planterColor;
	@Column(name="planttshape",length=50)
	String planterShape;
	@Column(name="planttstock")
	int planterStock;
	@Column(name="cost")
	int planterCost;


 @OneToOne(cascade = CascadeType.ALL) 
 @JoinColumn(name="plantId")
 Plant plants; 
@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="seedId")
  Seed seeds;
	
	
	public Planter(Integer planterId, float planterHeight, int planterCapacity, int drinageHoles, int planterColor,
			String planterShape, int planterStock, int planterCost, Plant plants, Seed seeds) {
		super();
		this.planterId = planterId;
		this.planterHeight = planterHeight;
		this.planterCapacity = planterCapacity;
		this.drinageHoles = drinageHoles;
		this.planterColor = planterColor;
		this.planterShape = planterShape;
		this.planterStock = planterStock;
		this.planterCost = planterCost;
		this.plants = plants;
		this.seeds = seeds;
	}

	public Planter() {
	super();
}

	public Integer getPlanterId() {
		return planterId;
	}

	public void setPlanterId(Integer planterId) {
		this.planterId = planterId;
	}

	public float getPlanterHeight() {
		return planterHeight;
	}

	public void setPlanterHeight(float planterHeight) {
		this.planterHeight = planterHeight;
	}

	public int getPlanterCapacity() {
		return planterCapacity;
	}

	public void setPlanterCapacity(int planterCapacity) {
		this.planterCapacity = planterCapacity;
	}

	public int getDrinageHoles() {
		return drinageHoles;
	}

	public void setDrinageHoles(int drinageHoles) {
		this.drinageHoles = drinageHoles;
	}

	public int getPlanterColor() {
		return planterColor;
	}

	public void setPlanterColor(int planterColor) {
		this.planterColor = planterColor;
	}

	public String getPlanterShape() {
		return planterShape;
	}

	public void setPlanterShape(String planterShape) {
		this.planterShape = planterShape;
	}

	public int getPlanterStock() {
		return planterStock;
	}

	public void setPlanterStock(int planterStock) {
		this.planterStock = planterStock;
	}

	public int getPlanterCost() {
		return planterCost;
	}

	public void setPlanterCost(int planterCost) {
		this.planterCost = planterCost;
	}

	public Plant getPlants() {
		return plants;
	}

	public void setPlants(Plant plants) {
		this.plants = plants;
	}

	public Seed getSeeds() {
		return seeds;
	}

	public void setSeeds(Seed seeds) {
		this.seeds = seeds;
	}

	@Override
	public String toString() {
		return "Planter [planterId=" + planterId + ", planterHeight=" + planterHeight + ", planterCapacity="
				+ planterCapacity + ", drinageHoles=" + drinageHoles + ", planterColor=" + planterColor
				+ ", planterShape=" + planterShape + ", planterStock=" + planterStock + ", planterCost=" + planterCost
				+ ", plants=" + plants + ", seeds=" + seeds + "]";
	}
	
	
	

	
	

	
	

}