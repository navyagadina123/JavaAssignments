package com.cg.opna;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.opna.exception.CustomerAlreadyPresentException;
import com.cg.opna.exception.CustomerNotFoundException;
import com.cg.opna.exception.ErrorInfo;
import com.cg.opna.exception.OrderAlreadyPresentException;
import com.cg.opna.exception.OrderNotFoundException;
import com.cg.opna.exception.PlantAlreadyPresentException;
import com.cg.opna.exception.PlantNotFoundException;
import com.cg.opna.exception.PlanterAlreadyPresentException;
import com.cg.opna.exception.PlanterNotFoundException;
import com.cg.opna.exception.SeedAlreadyPresentException;
import com.cg.opna.exception.SeedNotFoundException;

@ControllerAdvice
public class GlobalException {
	@ExceptionHandler(PlantNotFoundException.class)
	public @ResponseBody ErrorInfo plantExceptionError(PlantNotFoundException e,HttpServletRequest req) {
		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
	}
    @ExceptionHandler(SeedNotFoundException.class)
	public @ResponseBody ErrorInfo seedExceptionError(SeedNotFoundException e,HttpServletRequest req) {
		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
	}
    @ExceptionHandler(PlanterNotFoundException.class)
   	public @ResponseBody ErrorInfo planterExceptionError(PlanterNotFoundException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    @ExceptionHandler(OrderNotFoundException.class)
   	public @ResponseBody ErrorInfo orderExceptionError(OrderNotFoundException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    
    @ExceptionHandler(CustomerNotFoundException.class)
   	public @ResponseBody ErrorInfo customerExceptionError(CustomerNotFoundException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    @ExceptionHandler(CustomerAlreadyPresentException.class)
   	public @ResponseBody ErrorInfo customerAlreadyPresentExceptionError(CustomerAlreadyPresentException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}

    @ExceptionHandler(PlanterAlreadyPresentException.class)
   	public @ResponseBody ErrorInfo planterAlreadyPresentExceptionError(PlanterAlreadyPresentException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    @ExceptionHandler(PlantAlreadyPresentException.class)
   	public @ResponseBody ErrorInfo plantAlreadyPresentExceptionError(PlantAlreadyPresentException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    @ExceptionHandler(SeedAlreadyPresentException.class)
   	public @ResponseBody ErrorInfo  seedAlreadyPresentExceptionError(SeedAlreadyPresentException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}
    @ExceptionHandler(OrderAlreadyPresentException.class)
   	public @ResponseBody ErrorInfo orderAlreadyPresentExceptionError(OrderAlreadyPresentException e,HttpServletRequest req) {
   		return new ErrorInfo(LocalDateTime.now(),e.getMessage(),req.getRequestURI());
   	}


}
