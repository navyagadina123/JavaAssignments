package com.cg.opna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.CustomerAlreadyPresentException;
import com.cg.opna.exception.CustomerNotFoundException;
import com.cg.opna.model.Customer;
import com.cg.opna.service.CustomerService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {
	@Autowired
	CustomerService service;
	
	@PostMapping("/addcustomer" )
 	public Customer addCustomer(@RequestBody Customer customer) throws CustomerAlreadyPresentException  {
		if(customer==null) {
			throw new CustomerAlreadyPresentException("Your customer already present");
		}
		else {
			return service.addCustomer(customer);
		}	
     }	
	@PutMapping( "/updatecustomer")
	public  Customer updateCustomer(@RequestBody Customer tenant) throws CustomerNotFoundException 
	{
		Customer cust=service.updateCustomer(tenant);
		return cust;	
	}
	
	@GetMapping("/viewcustomer/{customerId}" )
	public Customer viewCustomer(@PathVariable int customerId) throws CustomerNotFoundException
	{
		return (service.viewCustomer(customerId));
		
	}
	@GetMapping("/viewallcustomers")
	public List<Customer> viewAllCustomers() throws CustomerNotFoundException
	{
		return service.viewAllCustomers();
		
	}
	
	@DeleteMapping("/deletecustomer" )
	public Customer deleteCustomer(@RequestBody Customer tenant)throws CustomerNotFoundException
	{
	return service.deleteCustomer(tenant);
	}
	
	@GetMapping(path="/validate/{userName}/{password}") 
	public Customer validateCustomer(@PathVariable String userName, @PathVariable String password) throws CustomerNotFoundException
	{
		
		return (service.validateCustomer(userName, password));
	}

}