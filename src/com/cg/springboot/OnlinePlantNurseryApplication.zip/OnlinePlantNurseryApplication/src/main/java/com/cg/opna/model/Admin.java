/*package com.cg.opna.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="admin_tbl")
	public class Admin {
		@Id
		Integer adminId;
		@Column(name="adminUsername", length=20)
		String adminUsername;
		@Column(name="adminPassword", length=20)
		String adminPassword;
		public Admin() {
			super();
		}
		public Admin(Integer adminId, String adminUsername, String adminPassword) {
			super();
			this.adminId = adminId;
			this.adminUsername = adminUsername;
			this.adminPassword = adminPassword;
		}
		public Integer getAdminId() {
			return adminId;
		}
		public void setAdminId(Integer adminId) {
			this.adminId = adminId;
		}
		public String getAdminUsername() {
			return adminUsername;
		}
		public void setAdminUsername(String adminUsername) {
			this.adminUsername = adminUsername;
		}
		public String getAdminPassword() {
			return adminPassword;
		}
		public void setAdminPassword(String adminPassword) {
			this.adminPassword = adminPassword;
		}
		@Override
		public String toString() {
			return "Admin [adminId=" + adminId + ", adminUsername=" + adminUsername + ", adminPassword="
					+ adminPassword + "]";
		}
		
		

	}



*/