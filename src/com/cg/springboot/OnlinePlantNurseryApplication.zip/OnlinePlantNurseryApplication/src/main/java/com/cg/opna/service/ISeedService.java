package com.cg.opna.service;

import java.util.List;

import com.cg.opna.exception.SeedAlreadyPresentException;
import com.cg.opna.exception.SeedNotFoundException;
import com.cg.opna.model.Seed;

public interface ISeedService  {
	public	Seed addSeed(Seed seed)throws SeedAlreadyPresentException;
	public Seed updateSeed(Seed seed)throws SeedNotFoundException;
	public Seed deleteSeed(Seed seed)throws SeedNotFoundException;
	public Seed viewSeed(int seedId) throws SeedNotFoundException;
	public Seed viewSeed(String commonName)throws SeedNotFoundException;
	public List<Seed> viewAllSeeds()throws SeedNotFoundException;
	public List<Seed> viewAllSeeds(String typeOfseeds)throws SeedNotFoundException;

	

}


