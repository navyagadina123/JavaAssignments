package com.cg.opna.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

	@Entity
	@Table(name="admin_tbl")
	public class Login {

		@Id
		int loginId;
		
		@Column(name = "login_Name")
		String loginName;
		
		
		
		
		@OneToOne(targetEntity = User.class)
		private User user;

		
		public Login() {
			super();
		}


		public Login(int loginId,User user,String loginName) {
			super();
			this.loginId = loginId;
			this.user = user;
		}


		public int getloginId() {
			return loginId;
		}


		public void setloginId(int loginId) {
			this.loginId = loginId;
		}

		public String getloginName() {
			return loginName;
		}


		public void setloginName(String loginName) {
			this.loginName = loginName;
		}
		public User getUser() {
			return user;
		}


		public void setUser(User user) {
			this.user = user;
		}


		@Override
		public String toString() {
			return "Login [loginId=" + loginId + ", user="+ user +"]";
		}
		
		

			
	}


