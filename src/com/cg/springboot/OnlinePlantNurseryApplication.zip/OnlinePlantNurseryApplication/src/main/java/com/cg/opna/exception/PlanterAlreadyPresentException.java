package com.cg.opna.exception;

public class PlanterAlreadyPresentException extends Exception {
	public PlanterAlreadyPresentException(String str) {
		super(str);
	}
}

