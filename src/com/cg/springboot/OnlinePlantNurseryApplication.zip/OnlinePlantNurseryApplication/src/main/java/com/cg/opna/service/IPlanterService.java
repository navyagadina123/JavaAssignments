package com.cg.opna.service;

import java.util.List;

import com.cg.opna.exception.PlanterAlreadyPresentException;
import com.cg.opna.exception.PlanterNotFoundException;
import com.cg.opna.model.Planter;

public interface IPlanterService {
	Planter addPlanter(Planter planter) throws PlanterAlreadyPresentException;
	Planter updatePlanter(Planter planter) throws PlanterNotFoundException;
	Planter deletePlanter(Planter planter) throws PlanterNotFoundException ;
	Planter viewPlanter(int planterId) throws PlanterNotFoundException;
	Planter viewPlanter(String planterShape)throws PlanterNotFoundException;
	List<Planter> viewAllPlanters() throws PlanterNotFoundException;
	List<Planter> viewAllPlanters(int minCost, int maxCost) throws PlanterNotFoundException;

	
	
	

}
