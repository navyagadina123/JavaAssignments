package com.cg.opna.service;
import java.util.List;
import javax.security.auth.login.LoginException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.opna.dao.LoginDao;
import com.cg.opna.exception.UserNotFoundException;
import com.cg.opna.model.User;



@Service
public class ILoginServiceImpl implements LoginService{

	@Autowired
	LoginDao dao;
	 User usr;
	

	@Override
	 public User addUser(User users) throws UserNotFoundException{
		 
	 	if(dao.existsById(users.getUserid()))
		 
			throw new UserNotFoundException("User id already exist");
	 	
		else
		{
			User usr=dao.save(users);
			return usr;
		}

    }
	

	@Override
	public String removeUser(String users)throws UserNotFoundException {
		usr = null;
		if(dao.existsById(users)) {
	    	usr= dao.findById(users).get();
	    	dao.deleteById(users);
	   		return users;
	    		
	    	}
		else
		{
			throw new UserNotFoundException("User id does not exist");
		}
		
	}
		 
	    	
	    	
		
	
	@Override
	@Transactional
	public User validateUser(User users) throws LoginException{
		
		User u = null;
		String userid=users.getUserid();
		if(dao.existsById(userid))
		{
			u=dao.findById(userid).get();
			return u;
		}
		else
		{
			throw new LoginException("UserId Cant be null");
		}
	}
	public List<User> getallusers()
	{
		List<User> ulist = dao.findAll();
		return ulist;
	}
	
	
	@Override
	public User signIn(String userId)throws UserNotFoundException {
		User userSignIn = null;
		if (dao.existsById(userId)) {
			userSignIn = dao.findById(userId).get();
			return userSignIn;
		} else
			throw new UserNotFoundException("User doesn't exists");
	}

	@Override
	
	public User signOut(String userId) throws UserNotFoundException {
		User userSignOut = null;
		if (dao.existsById(userId)) {
			userSignOut = dao.findById(userId).get();
			return userSignOut;
		} else
			throw new UserNotFoundException("User doesn't exists");
	}


	
}