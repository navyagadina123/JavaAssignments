package com.cg.opna.controller;
import java.time.LocalDateTime;
import java.util.List;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.ErrorInfo;
import com.cg.opna.exception.UserNotFoundException;
import com.cg.opna.model.User;
import com.cg.opna.service.ILoginServiceImpl;

	
	@RestController
	@CrossOrigin(origins = "http://localhost:3000")
	public class UserController  {
		
		
		@Autowired
		ILoginServiceImpl service;
		
		@PostMapping("/addUser")
		public User addUser(@RequestBody User users) throws UserNotFoundException{
			
			return service.addUser(users);
			
			
			}
		
	    	
	    	
			 
			 @GetMapping("/allusers")
			 public List<User> getallusers()
			 {
				 List<User> ulist=service.getallusers();
				 return ulist;
			 }
			 
			 @GetMapping("/validate/{userid}")
			 public User validateUser(@PathVariable("userid") User users) throws LoginException
			 {
				 
			 User u=service.validateUser(users);
			 return u;
			 }
				 
			 @GetMapping("/signIn/{id}")
				public String signIn(@PathVariable String id) throws UserNotFoundException{ {
					User userSignIn = service.signIn(id);
					if(userSignIn!=null) {
					return "Sign in successfully";
					}
					else
						return "Sorry! No UserId exists";
				}
			 }
					
				

				@GetMapping("/signOut/{id}")
				public String signOut(@PathVariable String id) throws UserNotFoundException{ {
					User userSignOut = service.signOut(id);
					if(userSignOut!=null) {
						return "SignOut done successfully";
						}
						else
							return "Sorry! No UserId exists";
				
				 
				 }
				}
			 
			 
			 
			 @ExceptionHandler(UserNotFoundException.class)
			    public @ResponseBody ErrorInfo getExeptionHandler(Exception e, HttpServletRequest req) {
					
					  return new ErrorInfo(LocalDateTime.now(), e.getMessage(),req.getRequestURI());
			 }
	}


