package com.cg.opna.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opna.dao.ISeedDao;
import com.cg.opna.exception.SeedAlreadyPresentException;
import com.cg.opna.exception.SeedNotFoundException;
import com.cg.opna.model.Seed;
@Service
public class SeedService implements ISeedService {
	@Autowired
	ISeedDao dao;
	
	
	public Seed addSeed(Seed seed) throws SeedAlreadyPresentException {
		Optional<Seed> newSeed = dao.findById(seed.getSeedId());
		if(newSeed.isPresent()) {
			throw new SeedAlreadyPresentException("Your plant is Already Present"+seed.getSeedId());
		}
		else {
			Seed s = dao.save(seed);
			return s;
		}
	}

	
	public Seed updateSeed(Seed seed) throws SeedNotFoundException {
		if(dao.existsById(seed.getSeedId())) {
			Seed s = dao.save(seed);
			return s;
		}
		throw new SeedNotFoundException("seed not Found with given"+seed.getSeedId());
		
	}


	public Seed deleteSeed(Seed seed) throws SeedNotFoundException {
		if(dao.existsById(seed.getSeedId())) {
			Seed s = dao.findById(seed.getSeedId()).get();
			dao.deleteById(seed.getSeedId());
			return s;
		}
		throw new SeedNotFoundException("Seed not Found with given"+seed);
	}

	
	public Seed viewSeed(int seedId)throws SeedNotFoundException  {
		Optional<Seed> op = dao.findById(seedId);
		if(op.isPresent()) {	
			Seed s = op.get();
			return s;
		}
		else {
			throw new SeedNotFoundException("Seed not found with id: "+seedId);
		}

		
	}

	
	public Seed viewSeed(String commonName)throws SeedNotFoundException   {
		Seed s = dao.viewSeed(commonName);
		if(s==null) {
			throw new SeedNotFoundException("Seed not Found.");
		}
		else {
			return s;
		}
		
	}
	public List<Seed> viewAllSeeds()throws SeedNotFoundException   {
		List<Seed> sList = dao.findAll();
		if(sList.isEmpty()) {
			throw new SeedNotFoundException("Seeds not Found.");
		}
		else {
			return sList;
		}
		
	}
	public List<Seed> viewAllSeeds(String typeOfSeeds)throws SeedNotFoundException   {
		List<Seed> sList = dao.viewAllSeeds(typeOfSeeds);
		if(sList.isEmpty()) {
			throw new SeedNotFoundException("Seeds not Found.");
		}
		else {
			return sList;
		}
		
	}


}