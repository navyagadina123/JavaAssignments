package com.cg.opna.exception;

public class SeedNotFoundException extends Exception {
	public SeedNotFoundException(String str) {
		super(str);
	}
}