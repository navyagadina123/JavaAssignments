package com.cg.opna.model;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;

		@Entity
		@Table(name="Seed")
		public class Seed {
			@Id
			Integer seedId;
			@Column(name="CommonName")
			String commonName;
			@Column(name="bloomTime",length=50)
			String bloomTime;
			@Column(name="watering",length=50)
			String watering;
			@Column(name="difLev",length=50)
			String difficultyLevel;
			@Column(name="temp",length=20)
			String temperature;
			@Column(name="seedstype",length=50)
			String typeOfseeds;
			@Column(name="seeddes",length=12)
			String seedDescription;
			@Column(name="seedsStock")
			Integer seedsStock;
			@Column(name="seedscost")
			double seedscost;
			@Column(name="seedperPack")
			Integer seedsPerPacket;
			
			public Seed() {
				super();
			}
			public Seed(Integer seedId, String commonName, String bloomTime, String watering, String difficultyLevel,
					String temperature, String typeOfseeds, String seedDescription, Integer seedsStock, double seedscost,
					Integer seedsPerPacket) {
				super();
				this.seedId = seedId;
				this.commonName = commonName;
				this.bloomTime = bloomTime;
				this.watering = watering;
				this.difficultyLevel = difficultyLevel;
				this.temperature = temperature;
				this.typeOfseeds = typeOfseeds;
				this.seedDescription = seedDescription;
				this.seedsStock = seedsStock;
				this.seedscost = seedscost;
				this.seedsPerPacket = seedsPerPacket;
			}
			public Integer getSeedId() {
				return seedId;
			}
			public void setSeedId(Integer seedId) {
				this.seedId = seedId;
			}
			public String getCommonName() {
				return commonName;
			}
			public void setCommonName(String commonName) {
				this.commonName = commonName;
			}
			public String getBloomTime() {
				return bloomTime;
			}
			public void setBloomTime(String bloomTime) {
				this.bloomTime = bloomTime;
			}
			public String getWatering() {
				return watering;
			}
			public void setWatering(String watering) {
				this.watering = watering;
			}
			public String getDifficultyLevel() {
				return difficultyLevel;
			}
			public void setDifficultyLevel(String difficultyLevel) {
				this.difficultyLevel = difficultyLevel;
			}
			public String getTemperature() {
				return temperature;
			}
			public void setTemperature(String temperature) {
				this.temperature = temperature;
			}
			public String getTypeOfseeds() {
				return typeOfseeds;
			}
			public void setTypeOfseeds(String typeOfseeds) {
				this.typeOfseeds = typeOfseeds;
			}
			public String getSeedDescription() {
				return seedDescription;
			}
			public void setSeedDescription(String seedDescription) {
				this.seedDescription = seedDescription;
			}
			public Integer getSeedsStock() {
				return seedsStock;
			}
			public void setSeedsStock(Integer seedsStock) {
				this.seedsStock = seedsStock;
			}
			public double getSeedscost() {
				return seedscost;
			}
			public void setSeedscost(double seedscost) {
				this.seedscost = seedscost;
			}
			public Integer getSeedsPerPacket() {
				return seedsPerPacket;
			}
			public void setSeedsPerPacket(Integer seedsPerPacket) {
				this.seedsPerPacket = seedsPerPacket;
			}
			@Override
			public String toString() {
				return "Seed [seedId=" + seedId + ", commonName=" + commonName + ", bloomTime=" + bloomTime + ", Watering="
						+ watering + ", difficultyLevel=" + difficultyLevel + ", temperature=" + temperature
						+ ", typeOfseeds=" + typeOfseeds + ", seedDescription=" + seedDescription + ", seedsStock="
						+ seedsStock + ", seedscost=" + seedscost + ", seedsPerPacket=" + seedsPerPacket + "]";
			}
			
	}


