package com.cg.opna.exception;

public class OrderAlreadyPresentException extends Exception{
		public OrderAlreadyPresentException(String str) {
			super(str);
		}

	}

