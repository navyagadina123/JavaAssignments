package com.cg.opna.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.opna.dao.OrderDao;
import com.cg.opna.exception.OrderAlreadyPresentException;
import com.cg.opna.exception.OrderNotFoundException;
import com.cg.opna.model.Order;


@Service
public class OrderService {
	@Autowired
	OrderDao dao;
	Order order;
      
     
public Order addOrder(Order order) throws OrderAlreadyPresentException {
		
		Optional<Order> newOrder = dao.findById(order.getBookingOrderId());
		if(newOrder.isPresent()) {
			throw new OrderAlreadyPresentException("Your Order is Already Present"+order.getBookingOrderId());
		}
		else {
			dao.save(order);
			return order;
		}
		
	}
	
   public Order updateOrder(Order order) throws OrderNotFoundException{
		
		
	   if(dao.existsById(order.getBookingOrderId())) {
		   Order update=dao.save(order);
		   return update;
		   
	   }
	   throw new OrderNotFoundException("order not Found with given"+order.getBookingOrderId());
   }
   
   public void deleteOrder(int orderId) throws OrderNotFoundException
	{
	  order = null;
		Optional<Order> or= this.dao.findById(orderId);
		if(or.isPresent())
		{
			this.dao.delete(or.get());
		}
		else {
			throw new OrderNotFoundException("order not found with id: "+orderId);
		}
		
	}
   
         
		
		
	public Order viewOrder(int orderId) throws OrderNotFoundException {
		Optional<Order> orderdb = this.dao.findById(orderId);
		if(orderdb.isPresent())
		{
			return orderdb.get();
		}
		else
		{
			throw new OrderNotFoundException("Order not found with id: "+orderId);
		}	
	}
	


	 public List<Order> viewAllOrders() throws OrderNotFoundException
	 {
		 List<Order> aList = dao.findAll();
		if(aList.isEmpty()) {
			throw new  OrderNotFoundException("No Records.");
		}
		else {
			return aList;
		}

	 }
	 }

//		public Order deleteOrder(Order order) {
//			if(dao.existsById(order.getBookingOrderId()))
//			{
//				Order delete=dao.findById(order.getBookingOrderId()).get();
//				dao.deleteById(order.getBookingOrderId()).get();
//				return delete;
//			}
//			return order;
//		}
      
		
		
	


