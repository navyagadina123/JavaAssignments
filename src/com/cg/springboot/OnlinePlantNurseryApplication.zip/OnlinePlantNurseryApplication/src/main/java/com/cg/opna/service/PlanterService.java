package com.cg.opna.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opna.dao.PlanterDao;
import com.cg.opna.exception.PlanterAlreadyPresentException;
import com.cg.opna.exception.PlanterNotFoundException;
import com.cg.opna.model.Planter;

@Service
public class PlanterService implements IPlanterService{
@Autowired
PlanterDao dao;
		
	public Planter addPlanter(Planter planter) throws PlanterAlreadyPresentException {
		Optional<Planter> newPlanter = dao.findById(planter.getPlanterId());
		if(newPlanter.isPresent()) {
			throw new PlanterAlreadyPresentException("Your planter is Already Present"+planter.getPlanterId());
		}
		else {
			Planter p = dao.save(planter);
			return p;
		}
	}

	
	public Planter updatePlanter(Planter planter) throws PlanterNotFoundException{
		if(dao.existsById(planter.getPlanterId())) {
			   Planter update=dao.save(planter);
			   return update;
			   
		   }
		else {
			throw new PlanterNotFoundException("Planter not found with "+planter.getPlanterId());
		}
		
	}

	
	public Planter deletePlanter(Planter planter) throws PlanterNotFoundException {
		if(dao.existsById(planter.getPlanterId())) {
			Planter p = dao.findById(planter.getPlanterId()).get();
			dao.deleteById(planter.getPlanterId());
			return p;
		}
		throw new PlanterNotFoundException("Planter not found with given planter"+planter);
	}

	
	public Planter viewPlanter(int planterId) throws PlanterNotFoundException {
		Optional<Planter> planterdb = this.dao.findById(planterId);
		if(planterdb.isPresent())
		{
			return planterdb.get();
		}
		else
		{
			throw new PlanterNotFoundException("Planter not found with id: "+planterId);
		}	
	}

	
	public Planter viewPlanter(String planterShape) throws PlanterNotFoundException {
		Planter p = dao.viewPlanter(planterShape);
		if(p==null) {
			throw new PlanterNotFoundException("Planter not found");
		}
		else {
			return p;
		}
	}

	
	public List<Planter> viewAllPlanters() throws PlanterNotFoundException{
		List<Planter> pList = dao.findAll();
		if(pList.isEmpty()) {
			throw new  PlanterNotFoundException("No Records.");
		}
		else {
			return pList;
		}
	}

	
	public List<Planter> viewAllPlanters(int minCost, int maxCost) throws PlanterNotFoundException {
		List<Planter> pList = dao.viewAllPlanters(minCost, maxCost);
		if(pList.isEmpty()) {
			throw new  PlanterNotFoundException("No Records.");
		}
		else {
			return pList;
		}
	}
}
