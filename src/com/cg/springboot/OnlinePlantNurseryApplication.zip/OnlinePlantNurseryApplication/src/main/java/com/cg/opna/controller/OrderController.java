package com.cg.opna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.OrderAlreadyPresentException;
import com.cg.opna.exception.OrderNotFoundException;
import com.cg.opna.model.Order;
import com.cg.opna.service.OrderService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class OrderController {
	@Autowired
	OrderService service;
	
	@PostMapping("/addorder")
	public Order addOrder(@RequestBody Order order)throws OrderAlreadyPresentException  {
		if(order==null) {
			throw new OrderAlreadyPresentException("Your order already present");
		}
		else {
			return service.addOrder(order);
		}
		
	}
				
	
	@PutMapping("/updateorder")
	public Order updateOrder(@RequestBody Order order) throws OrderNotFoundException
	{
		Order  cust=service.updateOrder(order);
		return cust;
	}
				
	
	@DeleteMapping("/deleteorder/{orderId}")
	public String deleteOrder(@PathVariable int orderId) throws OrderNotFoundException
	{
		service.deleteOrder(orderId);	
		return " Order deleted sucessfully";
	}
				
					
	
	@GetMapping("/vieworder/{orderId}")
	public Order viewOrder(@PathVariable("orderId") int orderId) throws OrderNotFoundException{
		Order order= service.viewOrder(orderId);
		if(order!=null) {
			return order;
		}
		else
			throw new  OrderNotFoundException("Order Not Found");
	}
				

				
	@GetMapping("/viewallorder")
	public List<Order> viewAllOrders() throws OrderNotFoundException
	{
		List<Order> aList= service.viewAllOrders();
		return aList;
					
	}
	

}
