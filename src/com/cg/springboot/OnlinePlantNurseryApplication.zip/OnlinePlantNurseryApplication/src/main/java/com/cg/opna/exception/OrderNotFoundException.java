package com.cg.opna.exception;
public class OrderNotFoundException extends Exception{
		public OrderNotFoundException(String str) {
			super(str);
		}

	}

