package com.cg.opna.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.opna.model.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer,Integer> {

	@Query("SELECT vc FROM Customer vc  WHERE vc.username=?1 AND vc.password=?2 ")
	Optional<Customer> validateCustomer(String userName, String password);
}
