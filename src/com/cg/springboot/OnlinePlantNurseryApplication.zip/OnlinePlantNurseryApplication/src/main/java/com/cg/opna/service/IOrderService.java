package com.cg.opna.service;

import java.util.List;

import com.cg.opna.exception.OrderAlreadyPresentException;
import com.cg.opna.exception.OrderNotFoundException;
import com.cg.opna.model.Order;

public interface IOrderService {
	public Order addOrder(Order order)throws OrderAlreadyPresentException;
	public Order updateOrder(Order order)throws OrderNotFoundException;
	public Order deleteOrder(Order order)throws OrderNotFoundException;
	public Order viewOrder(int orderid)throws OrderNotFoundException;
	public List<Order> viewAllOrders() throws OrderNotFoundException ;

	}

		

