package com.cg.opna.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.opna.model.Planter;

	@Repository
	public interface PlanterDao extends JpaRepository<Planter,Integer> {
		@Query("select e from Planter e where e.planterShape = ?1")
		public Planter viewPlanter(String planterShape);
		
		@Query("select e from Planter e where e.planterCost >= ?1 AND e.planterCost <= ?2")
		public List<Planter> viewAllPlanters(int minCost, int maxCost);
	}


