package com.cg.opna.service;

import java.util.List;

import com.cg.opna.exception.CustomerAlreadyPresentException;
import com.cg.opna.exception.CustomerNotFoundException;
import com.cg.opna.model.Customer;



public interface ICustomerService {
		
public Customer addCustomer(Customer customer) throws CustomerAlreadyPresentException ;
public Customer updateCustomer(Customer tenant)throws CustomerNotFoundException;
public Customer viewCustomer(int customerId)throws CustomerNotFoundException;
public List<Customer> viewAllCustomers() throws CustomerNotFoundException ;
public Customer deleteCustomer(Customer tenant)throws CustomerNotFoundException;
public Customer validateCustomer(String userName,String password) throws CustomerNotFoundException;

}
