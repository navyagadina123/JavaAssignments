package com.cg.opna.exception;

public class CustomerAlreadyPresentException extends Exception {
	public CustomerAlreadyPresentException(String str) {
		super(str);
	}

}
