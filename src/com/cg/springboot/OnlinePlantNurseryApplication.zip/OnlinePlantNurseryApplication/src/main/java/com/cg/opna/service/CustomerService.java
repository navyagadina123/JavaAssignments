package com.cg.opna.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opna.dao.CustomerDao;
import com.cg.opna.exception.CustomerAlreadyPresentException;
import com.cg.opna.exception.CustomerNotFoundException;
import com.cg.opna.model.Customer;



@Service
public class CustomerService implements ICustomerService {
	@Autowired
	CustomerDao dao;
	public Customer addCustomer(Customer customer) throws CustomerAlreadyPresentException {
		Optional<Customer> newCustomer = dao.findById(customer.getCustomerId());
		if(newCustomer.isPresent()) {	
			throw new CustomerAlreadyPresentException("Your customer is Already Present "+customer.getCustomerId());
		}
		else {
			dao.save(customer);
			return customer;
		}
	}

	@Override
	public Customer updateCustomer(Customer  tenant) throws CustomerNotFoundException {
		if(dao.existsById(tenant.getCustomerId())) {
			   Customer  update=dao.save(tenant);
			   return update;
	}
		throw new CustomerNotFoundException("Customer not Found with given"+tenant.getCustomerId());
	}

	@Override
	public Customer viewCustomer(int customerId) throws CustomerNotFoundException {
		Customer customer = null;
		Optional<Customer>op = dao.findById(customerId);
		if(op.isPresent())
		{
			customer= op.get();
		}
		
		else
		{
			throw new CustomerNotFoundException("Customer not Found with given Id"+customerId);
		}
			
		return customer;
	}

	@Override
	public List<Customer> viewAllCustomers() throws CustomerNotFoundException  {
		List<Customer> aList = dao.findAll();
		if(aList.isEmpty()) {
			throw new  CustomerNotFoundException("No Records.");
		}
		else {
			return aList;
		}
	}

	@Override
	public Customer deleteCustomer(Customer tenant) throws CustomerNotFoundException{
		if(dao.existsById(tenant.getCustomerId())) 
		 {
		  Customer delete=dao.findById(tenant.getCustomerId()).get();
		  dao.deleteById(tenant.getCustomerId());
		   return delete;
          }
		throw new CustomerNotFoundException("Customer not Found with given"+tenant);
	}
	
	public Customer validateCustomer(String userName, String password) throws CustomerNotFoundException  {
	
		Customer customer = null;
		
		Optional<Customer>op = dao.validateCustomer(userName,password);
		if(op.isPresent())
		{
			customer= op.get();
			return customer;
		}
		else {
			throw new  CustomerNotFoundException("Customer not Found");
		}
		

	}

}