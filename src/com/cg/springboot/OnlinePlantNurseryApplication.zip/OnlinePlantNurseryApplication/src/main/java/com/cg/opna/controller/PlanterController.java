package com.cg.opna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.PlanterAlreadyPresentException;
import com.cg.opna.exception.PlanterNotFoundException;
import com.cg.opna.model.Planter;
import com.cg.opna.service.PlanterService;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class PlanterController {
	
@Autowired
PlanterService service;
      @PostMapping("/addplanter")
          public Planter addPlanter(@RequestBody Planter planter) throws PlanterAlreadyPresentException{
	      if(planter==null) {
		       throw new PlanterAlreadyPresentException("Your Planter is  already present");
	       }
	      else {
	        	Planter p = service.addPlanter(planter);
		        return p;
	          }
         }

     @PutMapping("/updateplanter")
      public Planter updatePlanter (@RequestBody Planter planter)throws PlanterNotFoundException {
	     Planter p = service.updatePlanter(planter);
	      return p;
      }

     @DeleteMapping("/deleteplanter")
      public Planter deletePlanter(@RequestBody Planter planter)throws PlanterNotFoundException {
	      Planter p = service.deletePlanter(planter);
	      return p;
      }

     @GetMapping("/viewplanter/{planterId}")
        public Planter viewPlanter(@PathVariable("planterId") int planterId)throws PlanterNotFoundException {
	        Planter p = service.viewPlanter(planterId);
	        return p;
       }

    @GetMapping("allplanters")
    public List<Planter> viewAllPlanters()throws PlanterNotFoundException{
	 List<Planter> pList = service.viewAllPlanters();
	 return pList;
    }

    @GetMapping("/ViewPlanterByShape/{planterShape}")
    public Planter viewPlanter(@PathVariable("planterShape") String planterShape)throws PlanterNotFoundException {
	 Planter p = service.viewPlanter(planterShape);
	  return p;
   }

  @GetMapping("/viewplanters/{min}/{max}")
    public List<Planter> viewAllPlanters(@PathVariable("min") int minCost, @PathVariable("max") int maxCost)throws PlanterNotFoundException{
	 List<Planter> pList = service.viewAllPlanters(minCost, maxCost);
	 return pList;
  }

}