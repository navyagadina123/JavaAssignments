package com.cg.opna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.SeedAlreadyPresentException;
import com.cg.opna.exception.SeedNotFoundException;
import com.cg.opna.model.Seed;
import com.cg.opna.service.SeedService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class SeedController {
 @Autowired
 SeedService service;
	
  @PostMapping("/addseed")
  public Seed addSeed(@RequestBody Seed seed)throws SeedAlreadyPresentException {
		if(seed==null) {
			throw new SeedAlreadyPresentException("Your seed is already present");
		}
		else {
			Seed s = service.addSeed(seed);
			return s;
		}
	}
	
	@PutMapping("/updateseed")
	public Seed updateSeed(@RequestBody Seed seed) throws SeedNotFoundException {
		Seed s = service.updateSeed(seed);
		return s;
	}
	
	@DeleteMapping("/deleteseed")
	public Seed deleteSeed(@RequestBody Seed seed) throws SeedNotFoundException {
		Seed s = service.deleteSeed(seed);
		return s;
	}
	
	@GetMapping("/viewseed/{seedId}")
	public Seed viewSeed(@PathVariable("seedId") int seedId) throws SeedNotFoundException{
		Seed s = service.viewSeed(seedId);
		return s;
	}
	
	@GetMapping("/allseeds")
	public List<Seed> viewAllSeeds()throws SeedNotFoundException {
		List<Seed> sList = service.viewAllSeeds();
		return sList;
	}
	
	@GetMapping("viewoneseed/{commonName}")
	public Seed viewSeed(@PathVariable("commonName") String commonName) throws SeedNotFoundException{
		Seed s = service.viewSeed(commonName);
	return s;
	}

	@GetMapping("allseed/{typeOfseeds}")
	public List<Seed> viewAllSeeds(@PathVariable("typeOfseeds") String typeOfseeds)throws SeedNotFoundException{
		List<Seed> sList = service.viewAllSeeds(typeOfseeds);
		return sList;
		
	}

}

