package com.cg.opna.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opna.dao.PlantDao;
import com.cg.opna.exception.PlantAlreadyPresentException;
import com.cg.opna.exception.PlantNotFoundException;
import com.cg.opna.model.Plant;


@Service
public  class PlantService implements IPlantService{
 @Autowired
 PlantDao dao;
      @Override
    	public Plant addPlant(Plant plant)throws PlantAlreadyPresentException{
    	     Optional<Plant> plt = dao.findById(plant.getPlantId());
    	 		if(plt.isPresent()) {
	throw new PlantAlreadyPresentException("Your plant is Already Present"+plant.getPlantId());
    	 		}
    	 		else {
    	 			Plant p = dao.save(plant);
    	 			return p;
    	 		}
    	 	}

    	     @Override
    	 	public Plant updatePlant(Plant plant) throws PlantNotFoundException{
    	 		if(dao.existsById(plant.getPlantId())) {
    	 		Plant p = dao.save(plant);
    	 		return p;
    	 		}
    	 		throw new PlantNotFoundException("plant not Found with given"+plant.getPlantId());
    	 	}
    	     
    	     @Override
    	 	public Plant deletePlant(Plant plant) throws PlantNotFoundException{
    	 		if(dao.existsById(plant.getPlantId())) {
    	 			Plant p = dao.findById(plant.getPlantId()).get();
    	 			dao.deleteById(plant.getPlantId());
    	 			return p;
    	 		}
    	 		else {
    	 			throw new PlantNotFoundException("Plant not found with given plant"+plant);
    	 		}
    	 	}

    	 	@Override
    	 	public Plant viewPlant(int plantId) throws PlantNotFoundException {
    	 		Plant plant = null;
    	 		Optional<Plant> op = dao.findById(plantId);
    	 		if(op.isPresent())
    	 		{
    	 			plant= op.get();
    	 			return plant;
    	 		}
    	 		else {
    	 	throw new PlantNotFoundException("Plant not found with the given plantId"+plantId);
    	 		}
    	 		
    	 	}
    	     
    	     
    	     
    	 	public List<Plant> viewAllPlants() throws PlantNotFoundException
   		{
   		   List<Plant> aList = dao.findAll();
   			if(aList.isEmpty()) {
   				throw new PlantNotFoundException("No Records.");
   			}
   			else {
   				return aList;
   			}
   		}
    	    public Plant viewPlant(String commonName) throws PlantNotFoundException
   		{	
   		 	Plant plant= dao.viewPlant(commonName);
   			if(plant==null) {
   				throw new PlantNotFoundException("Plant not found");
   			}
   			else {
   				return plant;
   				}
   			}
    	   public List<Plant> viewAllPlants(String typeOfPlant) throws PlantNotFoundException {
  			
  			List<Plant>plant = dao.viewAllPlants(typeOfPlant);
  			if(plant.isEmpty()) {
  				throw new PlantNotFoundException("Plant not found");
  			}
  			else {
  				return plant;
  			}
  		}
}
