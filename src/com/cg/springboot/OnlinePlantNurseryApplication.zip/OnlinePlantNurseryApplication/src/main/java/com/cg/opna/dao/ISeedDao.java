package com.cg.opna.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.opna.model.Seed;

@Repository
public interface ISeedDao  extends JpaRepository<Seed,Integer>{
		
		@Query("select e from Seed e where e.commonName = ?1 ")
		public Seed viewSeed(String commonName);
		
		@Query("select e from Seed e where e.typeOfseeds = ?1 ")
		public List<Seed> viewAllSeeds(String typeOfseeds);

	}


