package com.cg.opna.exception;

public class PlanterNotFoundException extends Exception {
		public PlanterNotFoundException(String str) {
			super(str);
		}

	}



