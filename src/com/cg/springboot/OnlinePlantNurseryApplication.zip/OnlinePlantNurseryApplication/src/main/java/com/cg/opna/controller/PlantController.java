package com.cg.opna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opna.exception.PlantAlreadyPresentException;
import com.cg.opna.exception.PlantNotFoundException;
import com.cg.opna.model.Plant;
import com.cg.opna.service.PlantService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class PlantController {
	
		@Autowired
		PlantService service;
		
		@PostMapping("/addPlants")
		public Plant addPlant(@RequestBody Plant plant)throws PlantAlreadyPresentException {
			if(plant==null)
			{
				throw new PlantAlreadyPresentException("Your Plant is already present");
			}
		else 
		{
			return service.addPlant(plant);
		}
		}
		
		
		@PutMapping("/updatePlant")
		public Plant updatePlant(@RequestBody Plant plant) throws PlantNotFoundException {
			Plant plt = service.updatePlant(plant);
			return plt;
		}
		
		
		@DeleteMapping("/deleteplant" )
		public Plant deletePlant(@RequestBody Plant plant) throws PlantNotFoundException 
		{
			Plant plt=service.deletePlant(plant);
			return plt;
		}
		
		
       @GetMapping("/viewPlant/{plantId}")
	    
	    public Plant viewPlant(@PathVariable("plantId") int plantId) throws PlantNotFoundException {
	    	Plant plant=service.viewPlant(plantId);
	    	return plant;
	    	
	    }
       
     @GetMapping("/plantviewbyname/{commonName}")
   	public Plant viewPlant(@PathVariable("commonName") String commonName)throws PlantNotFoundException
   	{
   		return service.viewPlant(commonName);
   	}
   	
   	@GetMapping("/plantviewall")
   	public List<Plant> viewAllPlants() throws PlantNotFoundException
   	{
   		return service.viewAllPlants();
   	}
    
   	@GetMapping("/plantviewallbytype/{typeOfPlant}")
	public List<Plant> viewAllPlants(@PathVariable("typeOfPlant") String typeOfPlant)throws PlantNotFoundException
	{
		return service.viewAllPlants(typeOfPlant);
	}
       
}


