package com.cg.opna.service;
import java.util.List;
import javax.security.auth.login.LoginException;

import com.cg.opna.exception.UserNotFoundException;
import com.cg.opna.model.User;

	public interface LoginService {
		
	    public User addUser(User users) throws UserNotFoundException;;
		
		public String removeUser(String users) throws UserNotFoundException;
		
		
		public User validateUser(User users) throws LoginException;
		
		public List<User>getallusers();
		

		public User signIn(String userId) throws UserNotFoundException;

		public User signOut(String userId) throws UserNotFoundException;

		
		
		

	}



