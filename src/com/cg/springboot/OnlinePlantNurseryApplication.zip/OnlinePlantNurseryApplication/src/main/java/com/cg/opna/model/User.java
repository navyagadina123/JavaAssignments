package com.cg.opna.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name="user_tbl")
	public class User {
		
		@Id
		@Column(nullable = false, length = 64)
		private String userid;
		

		@Column(nullable = false, length = 64)
		private String password;
		
		@Column(nullable = false, length = 64)
		private String username;
		
			
		public User() {
			super();
		}
		
		public User(String userid, String password, String username) {
			super();
			this.userid = userid;
			this.username = username;
			this.password = password;
			
		}

		public String getUserid() {
			return userid;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}
		
		public String getusername() {
			return username;
		}
		public void setusername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		

		@Override
		public String toString() {
			return "User [userid=" + userid + ", username=" + username + ", password=" + password + "]";
		}

		
		
		


	}



