package com.cg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test{
	public static void main(String[] args) {
		Connection connection;
		
		try
		{
			Class.forName("org.postgresql.Driver");
			 connection=DriverManager.getConnection("jdbc:postgresql://localhost:1738/postgres","postgres","Password");
			
//			if(connection !=null) {
//				System.out.println("connection ok");
//			}else
//			{
//				System.out.println("not connected");
//			}
			Statement s= connection.createStatement();
			ResultSet rs= s.executeQuery("select * from emp");
			while(rs.next())
			{
				int eno=rs.getInt(1);
				String ename=rs.getString(2);
				String addrs=rs.getString(3);
				int sal=rs.getInt(4);
				
				
				System.out.println(eno+" "+ename+ " "+addrs+" "+sal);
				
			}
			rs.close();
			s.close();
			connection.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	
}