package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.Employee;
import com.cg.ems.util.DbUtil;

public class EmpDao {
	public ArrayList<Employee> getEmployees(){
		try
	   {
		Connection con = DbUtil.getConnection();
		ArrayList<Employee> empList = new ArrayList<Employee>();
		
		
		String cmd="select * from emp ";
        PreparedStatement ps = con.prepareStatement(cmd);
        ResultSet rs=ps.executeQuery();
        while(rs.next()) 
         {
        	 int eno=rs.getInt(1);
	         String ename= rs.getString(2);
	        String addrs= rs.getString(3);
	         int sal= rs.getInt(4);
	         Employee emp= new Employee(eno,ename,addrs,sal);
	         empList.add(emp);
	            	
        }
          return empList;
	   }
	     catch(Exception e)
	   {
			e.printStackTrace();
			return null;
			
	    }
   }
public boolean addEmployee(Employee emp) {
		
		try 
		{
			Connection con = DbUtil.getConnection();
			String cmd="insert into emp values(?,?,?,?)";
	        PreparedStatement ps = con.prepareStatement(cmd);
	        ps.setInt(1, emp.getEno());
	        ps.setString(2, emp.getEname());
	        ps.setString(3, emp.getAddrs());
	        ps.setInt(4, emp.getSal());
	        int n=ps.executeUpdate();
	        if(n>0)
	        	return true;
	       return false;
	         
	        
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 return false;
		}
		
	}
public Employee  searchEmployee(int eno) {
	try
	{
		Connection con=DbUtil.getConnection();
		String cmd="select * from emp where eno=?"+eno;
		PreparedStatement ps=con.prepareStatement(cmd);
		ps.setInt(1, eno);
		ResultSet rs=ps.executeQuery();
	    if(rs.next()==false)
	       System.out.println("no such record found");
	    else
	    	System.out.println(rs.getInt(1)+rs.getString(2)+rs.getString(3)+rs.getInt(4));
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	  return null;
	    	
	
}

	public boolean delEmployee(int eno) {
		try
		{
			Connection con=DbUtil.getConnection();
			String cmd="delete from emp where eno=?";
			PreparedStatement ps=con.prepareStatement(cmd);
			ps.setInt(1, eno);
				return ps.executeUpdate()>0;
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		
		}
		 return false;
	}
	public boolean modifyEmployee(Employee emp) {
		try
	  {
	    Connection con=DbUtil.getConnection();
		String cmd="update emp set addrs=? where ename=?";
		PreparedStatement ps=con.prepareStatement(cmd);
		ps.setString(1,"addrs");
		ps.setString(2, "ename");
		return ps.executeUpdate()>0;
	  }catch(Exception e) 
		{
			e.printStackTrace();
		}
		  return false;
		
	}
}
	


     