package com.cg.ems.presentation;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.Employee;
import com.cg.ems.service.EmpService;

public class EmpMain {

	public static void main(String[] args) {
       EmpService service = new EmpService();
		
		ArrayList<Employee> empList=service.getEmployees();
		for(Employee emp:empList)
		System.out.println(emp);
		
		
		Employee emp = new Employee(9,"bhavani","bang",4000);
		
		boolean flag=service.addEmployee(emp);
		if(flag)
			System.out.println("Record Added");
		else
			System.out.println("Sorry  no record added");
	}
}


			
////		System.out.println("enter the eno to search");
////		Scanner sa=new Scanner(System.in);
////		int n=sa.nextInt();
////		Employee e=service.searchEmployee(n);
////		if(n!=0)
////			System.out.println("sorry no id");
////		else
////			System.out.println("id exists");
//		
////		boolean flag1 =service.deleteEmployee(4);
////		if(flag1)
////			System.out.println("Record deleted successfully");
////		else
////			System.out.println("sorry no record deleted");
////		
//		
//Employee emp1=new Employee(8,"Sushma","dharwad",2000);
//	
//		boolean flag2 =service.modifyEmployee(emp1);
//		if(flag2)
//			System.out.println("data modified successfully");
//		else
//			System.out.println("sorry data cannot be modified");		
//		}
//	}
//		int eno=2;
//		Employee e=service.searchEmployee(2);
//		if(flag)
//			System.out.println("the details of the id");
//		else
//			System.out.println("Sorry  no id  exists");
//			
//	}
//
//
//
//
//	}


