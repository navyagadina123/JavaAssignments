package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.Employee;
import com.cg.ems.dao.EmpDao;

public class EmpService {

	EmpDao dao= null;
	public ArrayList<Employee> getEmployees(){
		dao= new EmpDao();
		ArrayList<Employee> empList=dao.getEmployees();
		return empList;
		
	}
	
	public boolean addEmployee(Employee emp) {
		dao= new EmpDao();
		boolean flag=dao.addEmployee(emp);
		return flag;
	}
	
	public Employee searchEmployee(int eno) {
		dao=new EmpDao();
		Employee emp=dao.searchEmployee(eno);
		return emp;
		
	}
	
	public boolean deleteEmployee(int eno) {
		dao=new EmpDao();
		boolean flag=dao.delEmployee(eno);
		return flag;
	}
	public boolean modifyEmployee(Employee emp) {
		dao=new EmpDao();
		boolean flag=dao.modifyEmployee(emp);
		return flag;
	}

	

}

