package com.cg.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	public static Connection getConnection() {
		Connection con=null;
		try {
	         Class.forName("org.postgresql.Driver");
	         con = DriverManager.getConnection("jdbc:postgresql://localhost:1738/postgres",
	            "postgres", "Password");
	         return con;
	}
		catch(Exception e) {
			e.printStackTrace();
			return con;
			
	    }	
	}
}
