package com.cg.ems;

public class Employee {
	int eno;
	String ename;
	String addrs;
	int sal;
	public Employee()
	{
		
	}
	public Employee(int eno, String ename, String addrs, int sal) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.addrs = addrs;
		this.sal = sal;
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getAddrs() {
		return addrs;
	}
	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", addrs=" + addrs + ", sal=" + sal + "]";
	}
	

}
