package com.cg;

import java.text.SimpleDateFormat;

public class Date {

	public static void main(String[] args) throws Exception {
		String dob="15/04/2010";
		//Date tdy=new Date();
		SimpleDateFormat sdf =new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date dt=sdf.parse(dob);
		System.out.println(sdf.format(dt));

	}

}
