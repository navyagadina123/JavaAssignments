package com.cg;

public class Test {

	public static void main(String[] args) {
	  System.out.println("hello this is my first maveen project");

	}

}
