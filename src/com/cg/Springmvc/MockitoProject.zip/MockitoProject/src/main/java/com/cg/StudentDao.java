package com.cg;

public class StudentDao {
      public String getResult(int rno,IStudent std)
      {
    	  if(std.getMarks(rno)>70)
    		  return "Pass";
    	  return "Fail";
      }
}
