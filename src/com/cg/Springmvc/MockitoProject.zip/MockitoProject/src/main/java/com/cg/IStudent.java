package com.cg;

public interface IStudent {
       public int getMarks(int rno);
}
