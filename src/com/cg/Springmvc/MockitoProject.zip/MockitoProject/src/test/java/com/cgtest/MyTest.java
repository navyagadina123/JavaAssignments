package com.cgtest;

import static org.junit.Assert.assertEquals;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

import org.junit.runner.RunWith;


import com.cg.IStudent;
import com.cg.StudentDao;
@RunWith(MockitoJUnitRunner.class)
public class MyTest{
	
	@Mock
	IStudent std;
	
	@InjectMocks
	StudentDao dao;
	
	public void myTest()
	{
		when(std.getMarks(5)).thenReturn(90);
		
		assertEquals("Pass",dao.getResult(5,std));
	}
	

}
